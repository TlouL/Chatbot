import openai
import os
from pathlib import Path
from flask import Flask, request, render_template_string, session, jsonify
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
import chromadb.utils.embedding_functions as embedding_functions
import chromadb
import markdown2  # Ensure markdown2 is installed using pip

# Load environment variables
load_dotenv()

# OpenAI API Configuration
openai.api_key = os.getenv('OPENAI_API_KEY')

# Flask application configuration
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')  # Make sure to set the secret key in your environment

# Initialize ChromaDB client
client = chromadb.Client()

# Directory where PDF files are stored
pdf_directory = Path(__file__).parent / "documents"

# Create an instance of OpenAIEmbeddingFunction
openai_ef = embedding_functions.OpenAIEmbeddingFunction(
    api_key=openai.api_key,
    model_name="text-embedding-ada-002"
)

# Create and populate collection only once when the application starts
collection_name = "my_collection"
try:
    client.delete_collection(name=collection_name)
    print(f"Existing collection '{collection_name}' deleted.")
except Exception as e:
    print(f"Collection '{collection_name}' does not exist or could not be deleted: {e}")

collection = client.create_collection(name=collection_name, embedding_function=openai_ef)

doc_id = 0
for pdf_file in pdf_directory.glob("*.pdf"):
    pdf_loader = PyPDFLoader(str(pdf_file))
    pages = pdf_loader.load_and_split()

    for page in pages:
        text = str(page.page_content)
        collection.add(documents=[text], metadatas=[{"page_number": doc_id}], ids=[str(doc_id)])
        doc_id += 1

@app.route('/', methods=['GET', 'POST'])
def home():
    if 'chat_history' not in session:
        session['chat_history'] = []

    if request.method == 'POST':
        question = request.form['question']
        answer = get_answer(question, session['chat_history'])
        session['chat_history'].append({
            "role": "user",
            "content": question,  # User's question
            "answer": markdown2.markdown(answer)  # Bot's answer
        })
        session.modified = True

    return render_template_string(HTML_TEMPLATE, chat_history=session['chat_history'])




def get_answer(question, chat_history):
    global collection

    # Query ChromaDB based on the user's question
    query_results = collection.query(query_texts=[question], n_results=5)
    documents = query_results['documents'][0]

    # Make sure documents is a list of strings (document texts)
    print(documents)  # Add this line for debugging purposes

    # Construct the conversation history for the prompt
    #history_text = "\n".join(f"Q: {exchange['content']}\nA: {exchange['answer']}" for exchange in chat_history if exchange['role'] == 'user')
    history_text = "\n".join(f"Q: {exchange.get('content')}\nA: {exchange.get('answer')}" 
                             for exchange in chat_history if exchange.get('role') == 'user')



    # Include the most relevant document text in the prompt
    context_from_docs = "\n\n".join(documents[:3])
    prompt_text = f"{context_from_docs}\n\n{history_text}\nQ: {question}\nA:"

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are a helpful assistant."},
                  {"role": "user", "content": prompt_text}],
        max_tokens=1024
    )
    return response.choices[0].message.content

@app.route('/clear-history', methods=['POST'])
def clear_history_route():
    # Clear the chat history from the session
    session['chat_history'] = []
    session.modified = True
    # Return a JSON response indicating the operation was successful
    return jsonify(success=True)




# HTML template for the web interface with Bootstrap for responsiveness and better styling
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>HSRC Research Chatbot</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            background-color: #e9ecef;
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }
        .header img {
            height: 50px;
            margin-right: 15px;
        }
        .chat-container {
            margin: 20px auto 0 auto;
            padding: 20px;
            border-radius: 5px;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
            width: 80%;
            max-width: 800px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: calc(100vh - 160px);
        }
        .chat-box {
            overflow-y: auto;
            padding: 10px;
        }
        .user-message, .bot-message {
            padding: 10px;
            border-radius: 20px;
            margin-bottom: 10px;
            width: fit-content;
        }
        .user-message {
            background-color: #dcf8c6;
            margin-left: auto;
        }
        .bot-message {
            background-color: #f1f0f0;
        }
        .message-input {
            display: flex;
            padding-top: 20px;
        }
        .form-control {
            border-radius: 20px;
            padding: 10px;
            margin-right: 10px;
            flex-grow: 1;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
        }
        .btn-secondary {
    /* existing styles */
    display: flex;
    align-items: center;
    justify-content: center;
}
.btn-secondary img {
    margin-right: 5px; /* Add some space between the image and text */
}

    </style>
</head>
<body>
    <div class="header">
        <img src="/static/HSRCLogo.jpg" alt="HSRC Logo">
        <h1>HSRC Research Chatbot</h1>
    </div>
    <div class="chat-container">
        <div id="chat-box" class="chat-box">
            
            {% for exchange in chat_history %}
                <div class="{{ 'user-message' if exchange.get('role', 'system') == 'user' else 'bot-message' }}">
                    <strong>{{ exchange.get('role', 'User').title() }}:</strong> 
                    <p>{{ exchange.get('content', '') | safe }}</p> <!-- Display the user's question -->
                    <p>{{ exchange.get('answer', '') | safe }}</p> <!-- Display the bot's answer -->
                </div>
            {% endfor %}
           
        </div>
        
        
        <form method="POST" class="message-input d-flex">
           <input type="text" id="question" name="question" class="form-control flex-grow-1" placeholder="Type your question here...">
          <button type="submit" class="btn btn-primary flex-fill">Submit</button>
          <button type="button" class="btn btn-secondary flex-fill">
    <img src="{{ url_for('static', filename='logo.png') }}" alt="Clear History" style="height: 20px;">
    
</button>

        </form>

    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var chatBox = document.getElementById('chat-box');
        chatBox.scrollTop = chatBox.scrollHeight;
        var form = document.querySelector('form');
        form.addEventListener('submit', function() {
            setTimeout(function() { chatBox.scrollTop = chatBox.scrollHeight; }, 100);
        });
        
        document.querySelector('.btn-secondary').addEventListener('click', function() {
    
          fetch('/clear-history', { method: 'POST' })
         .then(response => response.json())
         .then(data => {
        if (data.success) {
            // Clear the chat display
            var chatBox = document.getElementById('chat-box');
            chatBox.innerHTML = '';
         }
          });
     });
    </script>
</body>
</html>
"""

if __name__ == '__main__':
    app.run(debug=True, port=5002)
