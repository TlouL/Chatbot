import openai
import os
from langchain_community.document_loaders import PyPDFLoader
import chromadb.utils.embedding_functions as embedding_functions
import chromadb

# Load environment variables and set API key
load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')

# Initialize ChromaDB client
client = chromadb.Client()

# Create/Open the collection in ChromaDB
collection_name = "my_collection"
collection = client.get_or_create_collection(name=collection_name)

# Function to generate embeddings
def generate_embeddings(text):
    response = openai.Embedding.create(
        input=[text],
        model="text-embedding-ada-002"
    )
    return response['data'][0]['embedding']

# Load and process documents
pdf_directory = Path("path/to/documents")
doc_id = 0
for pdf_file in pdf_directory.glob("*.pdf"):
    pdf_loader = PyPDFLoader(str(pdf_file))
    pages = pdf_loader.load_and_split()
    for page in pages:
        text = str(page.page_content)
        embedding = generate_embeddings(text)
        # Add the document along with its embedding to ChromaDB
        collection.add(documents=[text], embeddings=[embedding], ids=[str(doc_id)])
        doc_id += 1
