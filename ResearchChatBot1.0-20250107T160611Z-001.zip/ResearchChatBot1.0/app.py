import openai
import os
from pathlib import Path
from flask import Flask, request, render_template_string, session, jsonify, redirect, url_for
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
import chromadb.utils.embedding_functions as embedding_functions
import chromadb
import markdown2

# Load environment variables
load_dotenv()

# OpenAI API Configuration
openai.api_key = os.getenv('OPENAI_API_KEY')

# Flask application configuration
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')

# Initialize ChromaDB client
client = chromadb.Client()

# Directory where PDF files are stored
pdf_directory = Path(__file__).parent / "documents"

# Create an instance of OpenAIEmbeddingFunction
openai_ef = embedding_functions.OpenAIEmbeddingFunction(
    api_key=openai.api_key,
    model_name="text-embedding-ada-002"
)

# Create and populate collection only once when the application starts
collection_name = "my_collection"
try:
    client.delete_collection(name=collection_name)
except Exception as e:
    pass

collection = client.create_collection(name=collection_name, embedding_function=openai_ef)

doc_id = 0
for pdf_file in pdf_directory.glob("*.pdf"):
    pdf_loader = PyPDFLoader(str(pdf_file))
    pages = pdf_loader.load_and_split()

    for page_number, page in enumerate(pages):
        text = str(page.page_content)
        collection.add(documents=[text], metadatas=[{"page_number": page_number}], ids=[str(doc_id)])
        doc_id += 1

cleared_chat_histories = []
next_history_id = 1

@app.route('/', methods=['GET', 'POST'])
def home():
    if 'chat_history' not in session:
        session['chat_history'] = []

    if request.method == 'POST':
        question = request.form.get('question')  # Use .get() to avoid KeyError
        if question:  # Check if the question is not None
            answer = get_answer(question)
            session['chat_history'].append({
                "role": "user",
                "content": question,
                "answer": answer
            })
            session.modified = True
            return jsonify({"answer": answer})  # Respond with JSON
        return jsonify({"answer": "No question received."})

    return render_template_string(HTML_TEMPLATE, chat_history=session.get('chat_history', []), cleared_chat_histories=cleared_chat_histories)

def get_answer(question):
    global collection
    
    # Query ChromaDB based on the user's question
    query_results = collection.query(query_texts=[question], n_results=5)
    documents = query_results['documents'][0]

    # Construct the conversation history for the prompt
    history_text = "\n".join(f"Q: {exchange['content']}\nA: {exchange['answer']}" 
                             for exchange in session.get('chat_history', []) if exchange['role'] == 'user')

    # Call OpenAI's ChatCompletion API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are a helpful assistant."},
                  {"role": "user", "content": history_text}],
        max_tokens=1024
    )

    # Extract the answer
    answer = response.choices[0].message.content

    # Return the answer as markdown converted to HTML
    return markdown2.markdown(answer)

@app.route('/clear-history', methods=['POST'])
def clear_history_route():
    global next_history_id
    if session.get('chat_history'):
        cleared_chat_histories.append({
            'id': next_history_id,
            'content': session['chat_history']
        })
        session['chat_history'] = []
        session.modified = True
        next_history_id += 1
        return jsonify(success=True, history_id=next_history_id - 1)
    return jsonify(success=False, message="No chat history to clear.")

@app.route('/get-history/<int:history_id>', methods=['GET'])
def get_history(history_id):
    history = next((item for item in cleared_chat_histories if item['id'] == history_id), None)
    if history:
        return jsonify(success=True, history=history['content'])
    return jsonify(success=False, message="History not found.")

# HTML template for the web interface with Bootstrap for responsiveness and better styling
HTML_TEMPLATE = """

<!DOCTYPE html>
<html>
<head>
    <title>HSRC Research Chatbot</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            background-color: #e9ecef;
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }
        .header img {
            height: 50px;
            margin-right: 15px;
        }
        .menu-bar {
            background-color: #f8f9fa;
            border-right: 1px solid #dee2e6;
            padding: 20px;
            height: calc(100vh - 80px); /* Adjust the height as per header and footer */
            overflow-y: auto;
        }
        
        .chat-box {
           overflow-y: auto; /* Enables vertical scrollbar if content overflows */
           max-height: 70vh; /* Adjust height as needed */
   
        }

        
        .chat-container {
            margin-left: 20px;
            padding: 20px;
            border-radius: 5px;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
            width: calc(100% - 280px); /* Adjust width according to the size of the menu bar */
            height: calc(100vh - 160px);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        /* Add further styling as needed */
    </style>
</head>
<body>
    <div class="header">
        <img src="/static/HSRCLogo.jpg" alt="HSRC Logo">
        <h1>HSRC Research Chatbot</h1>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3">
                <div class="menu-bar">
                    <h5>Chat History</h5>
                     <ul id="history-menu">
                         {% for history in cleared_chat_histories %}
                             <li data-history-id="{{ history['id'] }}">Chat history {{ loop.index }}</li>
                            {% endfor %}
                     </ul>
                </div>
            </div>
            <div class="col-9">
                <div class="chat-container">
                    <div id="chat-box" class="chat-box">
                        <!-- Chat history is rendered here -->
                        {% for exchange in chat_history %}
                            <div class="{{ 'user-message' if exchange.get('role', 'system') == 'user' else 'bot-message' }}">
                                <strong>{{ exchange.get('role', 'User').title() }}:</strong>
                                <p>{{ exchange.get('content', '') | safe }}</p>
<p>{{ exchange.get('answer', '') | safe }}</p> <!-- Display the bot's answer -->
                            </div>
                        {% endfor %}
                    </div>
                    <form method="POST" class="message-input d-flex">
                        <input type="text" id="question" name="question" class="form-control flex-grow-1" placeholder="Type your question here...">
                        <button type="submit" class="btn btn-primary flex-fill">Submit</button>
                        <button type="button" class="btn btn-secondary flex-fill" id="clear-history">Clear History</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var chatBox = document.getElementById('chat-box');
        chatBox.scrollTop = chatBox.scrollHeight;
        var form = document.querySelector('form');
        form.addEventListener('submit', function() {
            setTimeout(function() { chatBox.scrollTop = chatBox.scrollHeight; }, 100);
        });
        
        
        
           document.getElementById('clear-history').addEventListener('click', function() {
    fetch('/clear-history', { method: 'POST' })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            var chatBox = document.getElementById('chat-box');
            chatBox.innerHTML = '';
            var historyMenu = document.getElementById('history-menu');
            var newHistoryItem = document.createElement('li');
            newHistoryItem.textContent = 'Chat history ' + data.history_id;
            newHistoryItem.dataset.historyId = data.history_id;
            historyMenu.appendChild(newHistoryItem);
        }
    })
    .catch(error => console.error('Error:', error));
});

function retrieveHistory(historyId) {
    fetch('/get-history/' + historyId)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const chatBox = document.getElementById('chat-box');
            chatBox.innerHTML = '';
            data.history.forEach(msg => {
                const msgDiv = document.createElement('div');
                const roleClass = msg.role.toLowerCase() === 'user' ? 'user-message' : 'bot-message';
                const roleName = msg.role;
                msgDiv.classList.add(roleClass);
                msgDiv.innerHTML = `<strong>${roleName}:</strong><p>${msg.content}</p>`;
                chatBox.appendChild(msgDiv);
            });
            chatBox.scrollTop = chatBox.scrollHeight;
        }
    });
}

document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the default form submission behavior
    var questionInput = document.getElementById('question');
    var question = questionInput.value;
    questionInput.value = ''; // Clear the input after getting the value

    // Use fetch to send 'question' to your Flask server and handle the response
    fetch('/', {
        method: 'POST',
        body: new URLSearchParams({
            'question': question // Send as form data instead of JSON
        })
    })
    .then(response => response.json())
    .then(data => {
        // Update the chat history in the DOM with the new bot's response
        var chatBox = document.getElementById('chat-box');
        var botMessage = document.createElement('div');
        botMessage.classList.add('bot-message');
        botMessage.innerHTML = `<strong>Bot:</strong><p>${data.answer}</p>`;
        chatBox.appendChild(botMessage);
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(error => console.error('Error:', error));
});


    </script>
    
    
        </body>
</html>
"""

if __name__ == '__main__':
    app.run(debug=True, port=5002)

